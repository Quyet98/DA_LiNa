import "./GlobalStyles.scss"

function GlobalStyles({ children }) {
    return children;
}

export default GlobalStyles;

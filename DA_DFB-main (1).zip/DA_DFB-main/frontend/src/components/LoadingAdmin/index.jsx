import { Spin } from "antd";

const LoadingAmin = ({ IsLoad }) => {
  return (
    <>
      <Spin></Spin>
    </>
  );
};

export default LoadingAmin;
